package com.dandole.estasi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstasiApplication {

    public static void main(String[] args) {
        SpringApplication.run(EstasiApplication.class, args);
    }

}
